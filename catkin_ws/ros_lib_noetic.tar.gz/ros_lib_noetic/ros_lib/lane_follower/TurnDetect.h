#ifndef _ROS_lane_follower_TurnDetect_h
#define _ROS_lane_follower_TurnDetect_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace lane_follower
{

  class TurnDetect : public ros::Msg
  {
    public:
      typedef const char* _turn_direction_type;
      _turn_direction_type turn_direction;
      typedef float _pixel_size_type;
      _pixel_size_type pixel_size;
      typedef float _offset_type;
      _offset_type offset;

    TurnDetect():
      turn_direction(""),
      pixel_size(0),
      offset(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      uint32_t length_turn_direction = strlen(this->turn_direction);
      varToArr(outbuffer + offset, length_turn_direction);
      offset += 4;
      memcpy(outbuffer + offset, this->turn_direction, length_turn_direction);
      offset += length_turn_direction;
      union {
        float real;
        uint32_t base;
      } u_pixel_size;
      u_pixel_size.real = this->pixel_size;
      *(outbuffer + offset + 0) = (u_pixel_size.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_pixel_size.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_pixel_size.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_pixel_size.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->pixel_size);
      union {
        float real;
        uint32_t base;
      } u_offset;
      u_offset.real = this->offset;
      *(outbuffer + offset + 0) = (u_offset.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_offset.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_offset.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_offset.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      uint32_t length_turn_direction;
      arrToVar(length_turn_direction, (inbuffer + offset));
      offset += 4;
      for(unsigned int k= offset; k< offset+length_turn_direction; ++k){
          inbuffer[k-1]=inbuffer[k];
      }
      inbuffer[offset+length_turn_direction-1]=0;
      this->turn_direction = (char *)(inbuffer + offset-1);
      offset += length_turn_direction;
      union {
        float real;
        uint32_t base;
      } u_pixel_size;
      u_pixel_size.base = 0;
      u_pixel_size.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_pixel_size.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_pixel_size.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_pixel_size.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->pixel_size = u_pixel_size.real;
      offset += sizeof(this->pixel_size);
      union {
        float real;
        uint32_t base;
      } u_offset;
      u_offset.base = 0;
      u_offset.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_offset.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_offset.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_offset.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->offset = u_offset.real;
      offset += sizeof(this->offset);
     return offset;
    }

    virtual const char * getType() override { return "lane_follower/TurnDetect"; };
    virtual const char * getMD5() override { return "dc3e7f4e1cd3d92e1e9adc7c8d799597"; };

  };

}
#endif
